package com.yc.factory;

/**
 * @author Yanchen
 * date 2019/3/10 13:33
 */
public interface IMobilePhone {

    public String getName();

    public String getOperationSystem();

}
